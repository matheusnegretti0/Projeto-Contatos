<?php 
	$nome =$_POST["nome"];
	$nota1 =$_POST["nota1"];
	$peso1 =$_POST["peso1"];
	$nota2 =$_POST["nota2"];
	$peso2 =$_POST["peso2"];
	$nota3 =$_POST["nota3"];
	$peso3 =$_POST["peso3"];
    
    $somaNotas = ($nota1 * $peso1) + ($nota2 * $peso2) + ($nota3 * $peso3);

    $somaPesos = $peso1 + $peso2 + $peso3;

    $media = $somaNotas / $somaPesos;

    echo "<h1>Resultados</h1>";
    echo "<p>Nome do Aluno:" . $nome . "</p>";
    echo "<p>Média:" . $media . "</p>";
    echo   "<p>Soma das Notas:" .$somaNotas;
    echo  "<p>Soma dos Pesos:" .$somaPesos;
    echo  "<p>Média:" .$media;


if ($media > 7) {
        echo "<p>Situação: Aprovado</p>";
    } else if ($media > 4 && $media < 7) {
        echo "<p>Situação: Procure se esforçar para a recuperação</p>";
    } else if ($media < 4) {
        echo "<p>Situação: Reprovado</p>";
    } else {
    echo "<p>Método de requisição inválido.</p>";
}

 
?>