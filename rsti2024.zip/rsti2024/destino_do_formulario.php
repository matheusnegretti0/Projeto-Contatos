<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Retorno do Formulário</title>
</head>
<body>
	<?php
	$nome =$_POST["nome"];
	$email =$_POST["email"];
	$idade =$_POST["idade"];
	$cidade =$_POST['cidade'];
	$mensagem =$_POST['msg'];
	?>
	<main>
		<form>
		<section id="formulário">
			
			<label for="nome">Nome:</label>
			<?php echo $nome; ?><br><br>
			
			<label for="email"> E-mail:</label>
			<?php echo "Seu email:$email"; ?><br><br>
			

			<label for="idade">Idade:</label>
			<?php echo "Sua idade:" .$idade; ?><br><br>

			<label for="cidade">Cidade;</label>
			<?php echo "Cidade escolhida: $cidade"; ?><br><br>



		
		<label for="msg" name="msg">Mensagem:</label>
		<?php echo $mensagem ?><br><br>


		</section>


</body>
</html>