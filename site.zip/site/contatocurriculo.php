<?php
$nomeempresa =$_POST['nomeempresa'];
$nomedapessoa =$_POST['nomedapessoa'];
$email =$_POST['email'];
$telefone =$_POST['telefone'];
$mensagem =$_POST['mensagem'];

echo "<h1>CONTATO</h1>";
echo "<p> Nome da empresa:" .$nomeempresa ."</p>";
echo "<p> Nome da Pessoa:" .$nomedapessoa ."</p>";
echo "<p> Email:" .$email ."</p>";
echo "<p> Telefone:" .$telefone ."</p>";
echo "<p> Mensagem:" .$mensagem ."</p>";
?>