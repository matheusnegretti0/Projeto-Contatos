<?php 
$nomedapessoa =$_POST['nomedapessoa'];
$email =$_POST['email'];
$assunto =$_POST['assunto'];
$mensagem =$_POST['mensagem'];

echo "<h1>CONTATO</h1>";
echo "<p> Nome da Pessoa:" .$nomedapessoa ."</p>";
echo "<p> Email:" .$email ."</p>";
echo "<p> Telefone:" .$assunto ."</p>";
echo "<p> Mensagem:" .$mensagem ."</p>";

 ?>